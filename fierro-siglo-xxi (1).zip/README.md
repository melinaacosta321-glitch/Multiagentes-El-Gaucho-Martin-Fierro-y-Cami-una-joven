# Fierro y el siglo XXI · Escenario multiagente

Martín Fierro, el gaucho de 1879, conversa con Cami, una estudiante de historia de Formosa que viene del siglo XXI. La charla gira en torno a los valores, la libertad, el trabajo y lo que queda hoy del sentimiento criollo.

## Elenco
| Personaje | Agente de ElevenLabs |
|---|---|
| Martín Fierro | agent_4901m4w3412eem2txywgr9d07rd4 |
| Cami, joven urbana del siglo XXI | agent_7201m5kbx21dfdva4j4ab7dtj9zw |

## Cómo se usa
- **En vivo:** tocá «Empezar la charla» y hablá por micrófono. Para darle la palabra a uno, nombralo («Cami, ¿y vos qué pensás?») o tocá su nombre.
- **Guion:** trae un guion de ejemplo con cámaras. Se puede editar o generar con «Que charlen solos».
- **Cine:** modo de pantalla completa para proyectar en el aula.

## Publicar en GitHub Pages
1. Creá un repositorio nuevo y subí `index.html`.
2. Entrá en Settings → Pages → Deploy from a branch → `main` / root.
3. En unos minutos queda en `https://TU-USUARIO.github.io/NOMBRE-DEL-REPO/`.

Los agentes necesitan créditos de ElevenLabs para hablar.
